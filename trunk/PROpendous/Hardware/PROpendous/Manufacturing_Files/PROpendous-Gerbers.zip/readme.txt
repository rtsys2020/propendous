File Format: Gerber RS-274-X
Plot Origin: Absolute
Gerber Files:

	PROpendous-SoldP_Front.gbp	: Top/Front Layer Solder Paste Stencil

	PROpendous-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	PROpendous-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	PROpendous-Front.gtl		: Top/Front Copper Layer
	PROpendous-Back.gbl		: Bottom/Back Copper Layer
	PROpendous-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	PROpendous-SilkS_Back.gbo	: Bottom/Back Layer White Silkscreen
	PROpendous-PCB_Edges.gbr	: PCB Edge Outline

	PROpendous-SoldP_Back.gbp	: Bottom/Back Layer Solder Paste Stencil


Drill File: PROpendous.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 474
	Notes:  - No axis mirroring and only standard vias


Design Notes:
	- Design Size (X*Y): 3.03" x 2.39"
	- Design Detail: 7mil-7mil-15mil Trace-Clearance-Minimum_Drill
	- PROpendous-Drill_Sheet.pho Gerber shows all drill locations
